import React, { useState } from 'react';
import { Stethoscope, PawPrint, Heart, Search, ArrowRight, AlertCircle } from 'lucide-react';

type Symptom = {
  id: number;
  name: string;
  selected: boolean;
};

function App() {
  const [petType, setPetType] = useState<'dog' | 'cat' | null>(null);
  const [symptoms, setSymptoms] = useState<Symptom[]>([
    { id: 1, name: 'Lethargy', selected: false },
    { id: 2, name: 'Loss of appetite', selected: false },
    { id: 3, name: 'Vomiting', selected: false },
    { id: 4, name: 'Diarrhea', selected: false },
    { id: 5, name: 'Coughing', selected: false },
    { id: 6, name: 'Excessive thirst', selected: false },
  ]);
  const [result, setResult] = useState<string>('');

  const analyzeSymptoms = () => {
    const selectedSymptoms = symptoms.filter(s => s.selected).map(s => s.name);
    if (selectedSymptoms.length === 0) {
      setResult('Please select at least one symptom.');
      return;
    }
    
    setResult('Based on the symptoms selected, your pet may be experiencing digestive issues or general illness. Please consult with a veterinarian for a proper diagnosis. This is an AI-assisted preliminary assessment only.');
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Stethoscope className="h-8 w-8 text-blue-600" />
            <h1 className="text-2xl font-bold text-gray-900">VetAI Assistant</h1>
          </div>
          <nav className="flex space-x-4">
            <a href="#" className="text-gray-600 hover:text-blue-600 flex items-center space-x-1">
              <Search className="h-4 w-4" />
              <span>Symptom Checker</span>
            </a>
            <a href="#" className="text-gray-600 hover:text-blue-600 flex items-center space-x-1">
              <Heart className="h-4 w-4" />
              <span>Emergency</span>
            </a>
          </nav>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow-xl p-6 md:p-8">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-2xl font-semibold text-gray-900 mb-6">Pet Symptom Checker</h2>
            
            <div className="mb-8">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Select your pet type:</h3>
              <div className="flex space-x-4">
                <button
                  onClick={() => setPetType('dog')}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-lg ${
                    petType === 'dog'
                      ? 'bg-blue-100 text-blue-700 border-2 border-blue-500'
                      : 'bg-gray-100 text-gray-700 border-2 border-transparent'
                  } hover:bg-blue-50 transition-colors`}
                >
                  <PawPrint className="h-5 w-5" />
                  <span>Dog</span>
                </button>
                <button
                  onClick={() => setPetType('cat')}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-lg ${
                    petType === 'cat'
                      ? 'bg-blue-100 text-blue-700 border-2 border-blue-500'
                      : 'bg-gray-100 text-gray-700 border-2 border-transparent'
                  } hover:bg-blue-50 transition-colors`}
                >
                  <PawPrint className="h-5 w-5" />
                  <span>Cat</span>
                </button>
              </div>
            </div>

            <div className="mb-8">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Select symptoms:</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {symptoms.map((symptom) => (
                  <button
                    key={symptom.id}
                    onClick={() => {
                      setSymptoms(symptoms.map(s =>
                        s.id === symptom.id ? { ...s, selected: !s.selected } : s
                      ));
                    }}
                    className={`flex items-center space-x-2 px-4 py-3 rounded-lg ${
                      symptom.selected
                        ? 'bg-blue-100 text-blue-700 border-2 border-blue-500'
                        : 'bg-gray-100 text-gray-700 border-2 border-transparent'
                    } hover:bg-blue-50 transition-colors`}
                  >
                    <span>{symptom.name}</span>
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={analyzeSymptoms}
              className="w-full bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2"
            >
              <span>Analyze Symptoms</span>
              <ArrowRight className="h-5 w-5" />
            </button>

            {result && (
              <div className="mt-8 p-4 bg-yellow-50 border-l-4 border-yellow-400 rounded-r-lg">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <AlertCircle className="h-5 w-5 text-yellow-400" />
                  </div>
                  <div className="ml-3">
                    <p className="text-sm text-yellow-700">{result}</p>
                  </div>
                </div>
              </div>
            )}

            <div className="mt-8 text-sm text-gray-500">
              <p className="font-medium">Important Notice:</p>
              <p>This tool provides general guidance only and should not replace professional veterinary care. If your pet is experiencing severe symptoms or you're concerned about their health, please contact your veterinarian immediately.</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;